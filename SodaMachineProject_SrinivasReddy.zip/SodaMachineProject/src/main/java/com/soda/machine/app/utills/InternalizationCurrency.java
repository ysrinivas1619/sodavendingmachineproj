package com.soda.machine.app.utills;

import java.text.NumberFormat;
import java.util.Locale;

public class InternalizationCurrency {

	public static String formatCurrency(double amount) {

		NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.US);
		String currency = formatter.format(amount);
		return currency;
	}
}
