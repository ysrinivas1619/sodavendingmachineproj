package com.soda.machine.app.model;

import java.io.Serializable;

public class ItemRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String itemId;

	private String insertedPrice;

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getInsertedPrice() {
		return insertedPrice;
	}

	public void setInsertedPrice(String insertedPrice) {
		this.insertedPrice = insertedPrice;
	}

}
