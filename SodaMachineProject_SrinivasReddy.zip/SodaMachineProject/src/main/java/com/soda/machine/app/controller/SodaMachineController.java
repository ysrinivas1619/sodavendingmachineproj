package com.soda.machine.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.soda.machine.app.model.ItemRequest;
import com.soda.machine.app.model.ItemResponse;
import com.soda.machine.app.model.SodaModel;
import com.soda.machine.app.service.impl.SodaMachineServiceImpl;

@Controller
public class SodaMachineController<ResponceEntit> {

	private static final Logger LOGGER = LoggerFactory.getLogger(SodaMachineController.class);

	@Autowired
	private SodaMachineServiceImpl sodaMachineService;

	@GetMapping("/allItems")
	public String getAllItemDetails(Model model) {

		List<SodaModel> sodaList = null;
		try {
			//calling for getting list of items.
			sodaList = getSodaMachineService().getAllItemDetails();
			model.addAttribute("sodaItems", sodaList);
			model.addAttribute("itemRequest", new ItemRequest());
			model.addAttribute("itemResponse", new ItemResponse());

		} catch (Exception e) {
			LOGGER.error("Exception occurs getAllItemDetails() in SodaMachineController", e);
		}

		return "sodaItems";
	}

	@PostMapping("/itemCalculation")
	public String getItemCalculationDetails(@Valid ItemRequest itemRequest, Model model) {

		ItemResponse itemResponse = null;
		List<SodaModel> sodaList = null;

		try {
			//calculating the amount differences.
			itemResponse = getSodaMachineService().calculationItemDetails(itemRequest);
			sodaList = getSodaMachineService().getAllItemDetails();
		} catch (Exception e) {
			LOGGER.error("Exception occurs getItemCalculationDetails() in SodaMachineController", e);
		}

		model.addAttribute("sodaItems", sodaList);
		model.addAttribute("itemRequest", new ItemRequest());
		model.addAttribute("itemResponse", itemResponse);
		return "sodaItems";
	}

	@GetMapping("/sodaCount")
	public ResponseEntity<Integer> getSodaCountDetails() {

		Integer sodaCount = null;

		try {
			sodaCount = getSodaMachineService().getSodaCount();
		} catch (Exception e) {
			LOGGER.error("Exception occurs ResponseEntity() in SodaMachineController", e);
		}

		return ResponseEntity.ok(sodaCount);
	}

	public SodaMachineServiceImpl getSodaMachineService() {
		return sodaMachineService;
	}

	public void setSodaMachineService(SodaMachineServiceImpl sodaMachineService) {
		this.sodaMachineService = sodaMachineService;
	}

}
