package com.soda.machine.app.service;

import java.util.List;

import com.soda.machine.app.model.ItemRequest;
import com.soda.machine.app.model.ItemResponse;
import com.soda.machine.app.model.SodaModel;

public interface SodaMachineService {

	public List<SodaModel> getAllItemDetails() throws Exception;

	public ItemResponse calculationItemDetails(ItemRequest itemRequest) throws Exception;

}
