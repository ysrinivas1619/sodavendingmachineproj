package com.soda.machine.app.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.soda.machine.app.dao.SodaMachineDao;
import com.soda.machine.app.model.ItemRequest;
import com.soda.machine.app.model.SodaModel;

@Repository
public class SodaMachineDaoImpl implements SodaMachineDao {

	public List<SodaModel> getAllItems() throws Exception {

		// Instead of database preparing list of soda items.
		List<SodaModel> sodaList = getSodaItems();
		return sodaList;

	}

	public SodaModel getItemDetails(ItemRequest itemRequest) throws Exception {

		// By using itemId we need to retrieve the data from database
		List<SodaModel> sodaList = getSodaItems();
		Integer itemId = Integer.valueOf(itemRequest.getItemId());
		for (SodaModel sodaModel : sodaList) {

			if (sodaModel.getItemId().equals(itemId)) {
				return sodaModel;
			}
		}

		return null;
	}

	public Integer getSodaCount() throws Exception {

		// Instead of database,getting the list of soda count temporarily from list
		// items.

		Integer sodaCount = getSodaItems().size();

		return sodaCount;
	}

	private List<SodaModel> getSodaItems() {

		List<SodaModel> sodaList = new ArrayList<SodaModel>();

		SodaModel sodaModelOne = new SodaModel();
			sodaModelOne.setItemId(111);
			sodaModelOne.setItemName("Pepsi");
			sodaModelOne.setItemPrice(10d);
			sodaModelOne.setItemCount(2);
		sodaList.add(sodaModelOne);
		SodaModel sodaModelTwo = new SodaModel();
			sodaModelTwo.setItemId(222);
			sodaModelTwo.setItemName("Coke");
			sodaModelTwo.setItemPrice(20d);
			sodaModelTwo.setItemCount(7);
		sodaList.add(sodaModelTwo);
		SodaModel sodaModelThree = new SodaModel();
			sodaModelThree.setItemId(333);
			sodaModelThree.setItemName("Maaza");
			sodaModelThree.setItemPrice(30d);
			sodaModelThree.setItemCount(3);
		sodaList.add(sodaModelThree);
		
		return sodaList;
	}

}
