package com.soda.machine.app.model;

import java.io.Serializable;

public class ItemResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String itemName;
	private String priceDiffrence;
	private String displayMessage;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDisplayMessage() {
		return displayMessage;
	}

	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}

	public String getPriceDiffrence() {
		return priceDiffrence;
	}

	public void setPriceDiffrence(String priceDiffrence) {
		this.priceDiffrence = priceDiffrence;
	}

}
