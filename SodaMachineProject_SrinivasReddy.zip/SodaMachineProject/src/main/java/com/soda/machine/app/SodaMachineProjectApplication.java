package com.soda.machine.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SodaMachineProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SodaMachineProjectApplication.class, args);
	}

}
