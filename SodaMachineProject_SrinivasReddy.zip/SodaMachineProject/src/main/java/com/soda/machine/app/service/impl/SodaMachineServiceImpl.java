package com.soda.machine.app.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.soda.machine.app.dao.impl.SodaMachineDaoImpl;
import com.soda.machine.app.model.ItemRequest;
import com.soda.machine.app.model.ItemResponse;
import com.soda.machine.app.model.SodaModel;
import com.soda.machine.app.service.SodaMachineService;

@Service
public class SodaMachineServiceImpl implements SodaMachineService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SodaMachineServiceImpl.class);

	@Autowired
	private SodaMachineDaoImpl sodaMachineDao;

	public List<SodaModel> getAllItemDetails() throws Exception {
		List<SodaModel> sodaList = null;

		try {
			//calling repository 
			sodaList = getSodaMachineDao().getAllItems();
		} catch (Exception e) {
			LOGGER.error("Exception occurs getAllItemDetails() in SodaMachineServiceImpl", e);
			throw new Exception();
		}

		return sodaList;

	}

	public ItemResponse calculationItemDetails(ItemRequest itemRequest) throws Exception {
		ItemResponse itemResponse = null;
		try {
			itemResponse = new ItemResponse();
			SodaModel sodaModel = getSodaMachineDao().getItemDetails(itemRequest);

			if (!StringUtils.isEmpty(sodaModel) && !StringUtils.isEmpty(itemRequest)) {

				Double itemPrice = sodaModel.getItemPrice();
				Double insertedPrice = Double.valueOf(itemRequest.getInsertedPrice());

				Double priceDiffrence = itemPrice - insertedPrice;
				
				if (priceDiffrence > 0) {
					itemResponse.setItemName("Soda: " + sodaModel.getItemName());
					itemResponse.setDisplayMessage("Insufficient balance, Please add amount of $: " + priceDiffrence+ "+ for purchase for this item.");
					itemResponse.setPriceDiffrence("Amount Diffrence is $: " + priceDiffrence);
				} else if (priceDiffrence < 0) {
					itemResponse.setItemName("Soda: " + sodaModel.getItemName());
					itemResponse.setDisplayMessage(sodaModel.getItemName() + " dispense and collect remaining price $: "+ (-priceDiffrence) + "+");
					itemResponse.setPriceDiffrence("Amount Diffrence is $: " +(-priceDiffrence));
				} else {
					itemResponse.setItemName("Soda: " + sodaModel.getItemName());
					itemResponse.setDisplayMessage("Please collect the item " + sodaModel.getItemName());
					itemResponse.setPriceDiffrence("");
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception   occurs calculationItemDetails() in SodaMachineServiceImpl", e);

		}

		return itemResponse;

	}

	public Integer getSodaCount() throws Exception {
		Integer sodaCount = null;

		try {
			sodaCount = getSodaMachineDao().getSodaCount();
		} catch (Exception e) {
			LOGGER.error("Exception occurs getSodaCount() in SodaMachineServiceImpl", e);
			throw new Exception();
		}

		return sodaCount;

	}

	public SodaMachineDaoImpl getSodaMachineDao() {
		return sodaMachineDao;
	}

	public void setSodaMachineDao(SodaMachineDaoImpl sodaMachineDao) {
		this.sodaMachineDao = sodaMachineDao;
	}

}
