package com.soda.machine.app.dao;

import java.util.List;

import com.soda.machine.app.model.ItemRequest;
import com.soda.machine.app.model.SodaModel;

public interface SodaMachineDao {

	public List<SodaModel> getAllItems() throws Exception;
	
	public SodaModel getItemDetails(ItemRequest itemRequest) throws Exception;
	
	public Integer getSodaCount() throws Exception;

	
}